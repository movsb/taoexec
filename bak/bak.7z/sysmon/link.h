#ifndef __LINK_H__
#define __LINK_H__

#if _MSC_VER == 1200
#undef _WIN32_WINNT
#define _WIN32_WINNT 0x0501
#endif

#include <windows.h>

EXTERN_C int CreateShellLink(HWND hwnd, char drive, char* volume, char* link);

#endif//!__LINK_H__
