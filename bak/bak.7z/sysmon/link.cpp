#include "link.h"
#include <shobjidl.h>
#include <stdio.h>
#include <shlobj.h>

int CreateShellLink(HWND hwnd, char drive, char* volume, char* link)
{
	HRESULT hRet;
	IShellLink* pLink = NULL;
	IPersistFile* pPerFile = NULL;
	char path[MAX_PATH];
	char desktop[MAX_PATH];
	WCHAR desk[MAX_PATH];
	hRet = CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, IID_IShellLink, (void**)&pLink);
	if(hRet != S_OK)
	{
		MessageBox(hwnd, "IShellLink error", NULL, MB_OK);
		return 0;
	}
	hRet = pLink->QueryInterface(IID_IPersistFile, (void**)&pPerFile);
	if(hRet != S_OK)
	{
		MessageBox(hwnd, "IPersistFile error", NULL, MB_OK);
		return 0;
	}
	sprintf(path, "%c:\\", drive);
	pLink->SetPath(path);
	pLink->SetDescription("Ů������ nbsg.exe ����");
	GetModuleFileName(NULL, desktop, sizeof(desktop));
	pLink->SetIconLocation(desktop, 0);
	SHGetSpecialFolderPath(hwnd, desktop, CSIDL_DESKTOPDIRECTORY, FALSE);
	sprintf(path, "%s\\%s(%c).lnk", desktop, volume, drive);
	strcpy(link, path);
	MultiByteToWideChar(CP_ACP, 0, path, -1, desk, sizeof(desk));
	hRet = 1;
	if(pPerFile->Save(desk, TRUE) != S_OK)
	{
		hRet = 0;
		MessageBox(hwnd, "error Save shell link", NULL, MB_ICONERROR);
	}
	pPerFile->Release();
	pLink->Release();
	return hRet;
}