#define SYSMON_C
#include "sysmon.h"
#include "link.h"
#include "../nbsg/plugin/plugin.h"

nbsg_init_struct sysmon_nis;

WNDPROC wpOldMainWindowProc;
SYSTEM_POWER_STATUS system_power_status;

#if _MSC_VER > 1200
HPOWERNOTIFY hPowerNotify;

int enable_kbd_and_ms(void);
int disable_kbd_and_ms(void);
LRESULT CALLBACK LowLevelMouseProc(int nCode,WPARAM wParam,LPARAM lParam);
LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam);

#endif

EXPORT int nbsg_init(nbsg_init_struct* pnip)
{
	sysmon_nis.hInstance = pnip->hInstance;
	sysmon_nis.hWndMainWindow = pnip->hWndMainWindow;
	GetSystemPowerStatus(&system_power_status);
#if _MSC_VER > 1200
	hPowerNotify = RegisterPowerSettingNotification(sysmon_nis.hWndMainWindow,&GUID_LIDSWITCH_STATE_CHANGE,DEVICE_NOTIFY_WINDOW_HANDLE);
#endif
	wpOldMainWindowProc = (WNDPROC)SetWindowLong(pnip->hWndMainWindow,GWL_WNDPROC,(LONG)SysMonWindowProc);
	return 1;
}

EXPORT int nbsg_uninit(void)
{
	SetWindowLong(sysmon_nis.hWndMainWindow,GWL_WNDPROC,(LONG)wpOldMainWindowProc);
#if _MSC_VER > 1200
	UnregisterPowerSettingNotification(hPowerNotify);
	enable_kbd_and_ms();
#endif
	return 1;
}

//------------------------------------------------------------------------------------------------------------------------------------------------------


#if _MSC_VER > 1200

static int is_kbd_and_ms_enabled = 1;
HHOOK hKbdHook;
HHOOK hMsHook;


LRESULT CALLBACK LowLevelMouseProc(int nCode,WPARAM wParam,LPARAM lParam)
{
	if(is_kbd_and_ms_enabled==0){
		if(nCode == HC_ACTION){
			if(wParam != WM_MOUSEMOVE && wParam != WM_MOUSEWHEEL){
				MessageBeep(0xFFFFFFFF);
			}
			return 1;
		}
	}
	return CallNextHookEx(hMsHook,nCode,wParam,lParam);
}

LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if(is_kbd_and_ms_enabled==0){
		if(nCode == HC_ACTION){
			if(wParam == WM_KEYDOWN){
				PKBDLLHOOKSTRUCT pKbd = (PKBDLLHOOKSTRUCT)lParam;
				switch(pKbd->vkCode)
				{
				case VK_PAUSE:
					is_kbd_and_ms_enabled = 1;
					enable_kbd_and_ms();
					SendMessage(sysmon_nis.hWndMainWindow,NAM_SHOWTIPS,(WPARAM)"�������������������!",0);
					return 1;
				default:
					//MessageBeep(MB_ICONERROR);
					MessageBeep(0xFFFFFFFF);
					//SendMessage(sysmon_nis.hWndMainWindow,NAM_SHOWTIPS,(WPARAM)"���������ѱ�����, ��ֻ��ͨ���������ϵ� \"Pause\" ���ܴ�����!",0);
					return 1;
				}
			}
		}
	}
	return CallNextHookEx(hKbdHook, nCode, wParam, lParam);
}


int disable_kbd_and_ms(void)
{
	if(hKbdHook==NULL){
		hKbdHook = SetWindowsHookEx(WH_KEYBOARD_LL, (HOOKPROC)LowLevelKeyboardProc, sysmon_nis.hInstance, 0);
		if(!hKbdHook){
			MessageBox(NULL,"�޷���װ���̹���!",NULL,MB_ICONERROR);
			return 0;
		}
	}
	if(hMsHook == NULL){
		hMsHook = SetWindowsHookEx(WH_MOUSE_LL,(HOOKPROC)LowLevelMouseProc,sysmon_nis.hInstance,0);
		if(!hMsHook){
			MessageBox(NULL,"�޷���װ��깳��!",NULL,MB_ICONERROR);
			return 0;
		}
	}
	is_kbd_and_ms_enabled = 0;
	return 1;
}

int enable_kbd_and_ms(void)
{
	if(hKbdHook){
		UnhookWindowsHookEx(hKbdHook);
		hKbdHook = NULL; 
	}
	if(hMsHook){
		UnhookWindowsHookEx(hMsHook);
		hMsHook = NULL; 
	}
	is_kbd_and_ms_enabled = 1;
	return 1;
}

#endif

//------------------------------------------------------------------------------------------------------------------------------------------------------




LRESULT __stdcall SysMonWindowProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	if(uMsg == WM_POWERBROADCAST){
		if(wParam == PBT_APMPOWERSTATUSCHANGE){
			SYSTEM_POWER_STATUS sps;
			GetSystemPowerStatus(&sps);
			if(sps.ACLineStatus != system_power_status.ACLineStatus){
				char tmp_msg[128];
				if(sps.ACLineStatus) {
					_snprintf(tmp_msg, sizeof(tmp_msg),"��Դ��������!");
				} else {
					int hours, minutes;
					if(sps.BatteryLifeTime == 0xFFFFFFFF) {
						_snprintf(tmp_msg,sizeof(tmp_msg),"��Դ���ѶϿ�!\n���״̬:(�޷�ȡ��)\nʣ�����:%d%%", sps.BatteryLifePercent);
					} else {
						hours = sps.BatteryLifeTime/3600;
						minutes = (sps.BatteryLifeTime-hours*3600)/60;
						_snprintf(tmp_msg,sizeof(tmp_msg),"��Դ���ѶϿ�!\n���״̬:\n  ʣ�����:%d%%\n  ʣ��ʱ��:%02d:%02d",
							sps.BatteryLifePercent, hours, minutes);
					} 
				}
				SendMessage(sysmon_nis.hWndMainWindow,NAM_SHOWTIPS,(WPARAM)tmp_msg,0);
			}
			memcpy(&system_power_status,&sps,sizeof(sps));
#if _MSC_VER <= 1200
		}
#else
		}else if(wParam==PBT_POWERSETTINGCHANGE){
			POWERBROADCAST_SETTING* ppbs = (POWERBROADCAST_SETTING*)lParam;
			if(memcmp(&ppbs->PowerSetting,&GUID_LIDSWITCH_STATE_CHANGE,sizeof(GUID))==0){
				//1:opened,0-closed
				int lid_state = *(int*)ppbs->Data;
				
				if(lid_state==1){
					if(enable_kbd_and_ms()){
						SendMessage(sysmon_nis.hWndMainWindow,NAM_SHOWTIPS,(WPARAM)"�������������������!",0);
					}
				}else{
					if(disable_kbd_and_ms()){
						SendMessage(sysmon_nis.hWndMainWindow,NAM_SHOWTIPS,(WPARAM)"��������������ѱ�����, ʹ�� \'Pause\' ���������!",0);
					}
				}
			}
		}
#endif
		return TRUE;
	}else if(uMsg == WM_DEVICECHANGE){//-0---------------����ǰ�Ĵ����и��ƹ�����, д��̫����, �Ժ��ٸ�
		static char devList[4][MAX_PATH+1];
		DEV_BROADCAST_HDR* pdbh = (DEV_BROADCAST_HDR*)lParam;
		char szTmp[128],volumnName[64];

		if(wParam!=DBT_DEVICEARRIVAL && wParam!=DBT_DEVICEREMOVECOMPLETE)
			goto _default;	

		if(pdbh->dbch_devicetype == DBT_DEVTYP_VOLUME){
			DEV_BROADCAST_VOLUME* pdbv = (DEV_BROADCAST_VOLUME*)lParam;
			if(!(pdbv->dbcv_flags & DBTF_MEDIA)){
				DWORD unitmask = pdbv->dbcv_unitmask;
				int it;
				for(it=0; it<26; it++){
					if(unitmask & 1) break;
					else unitmask >>= 1;
				}
				sprintf(szTmp,"%c:\\",it+'A');
				if(wParam == DBT_DEVICEREMOVECOMPLETE){
					char str[32];
					int xxxx;
					for(xxxx=0;xxxx<sizeof(devList)/sizeof(devList[0]);xxxx++){
						if(devList[xxxx][0] == 'A'+it){
							DeleteFile(devList[xxxx]+1);
							devList[xxxx][0] = '\0';
							break;
						}
					}
					_snprintf(str,sizeof(str),"%c:\\ - ���Ƴ�!",it+'A');
					SendMessage(sysmon_nis.hWndMainWindow,NAM_SHOWTIPS,(WPARAM)str,0);
					return TRUE;
				}else{
					if(GetDriveType(szTmp) == DRIVE_REMOVABLE){
						int it2;
						GetVolumeInformation(szTmp,volumnName,sizeof(volumnName),NULL,NULL,NULL,NULL,0);
						for(it2=0; it2<sizeof(devList)/sizeof(devList[0]); it2++){
							if(devList[it2][0] == '\0')
								break;
						}
						if(it2 == sizeof(devList)/sizeof(devList[0])){
							SendMessage(sysmon_nis.hWndMainWindow,NAM_SHOWTIPS,(WPARAM)"�������ƶ�����̫��,�����Զ����������ݷ�ʽ!",0);
							return TRUE;
						}
						devList[it2][0] = (char)(it+'A');
						//---CreateLink
						CreateShellLink(sysmon_nis.hWndMainWindow,it+'A',*volumnName?volumnName:"���ƶ�����",devList[it2]+1);
						_snprintf(szTmp,sizeof(szTmp),"%s(%c:),�Ѵ��������ݷ�ʽ!",*volumnName?volumnName:"���ƶ�����",it+'A');
						SendMessage(sysmon_nis.hWndMainWindow,NAM_SHOWTIPS,(WPARAM)szTmp,0);
						return TRUE;
					}
				}
			}
		}
	}
_default:
	return CallWindowProc(wpOldMainWindowProc,hWnd,uMsg,wParam,lParam);
}
