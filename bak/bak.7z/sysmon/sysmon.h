#ifndef __SYSMON_H__
#define __SYSMON_H__

#include <windows.h>
#include <Dbt.h>
#include <stdio.h>
#include <string.h>

#ifdef SYSMON_C
#undef SYSMON_C

LRESULT __stdcall SysMonWindowProc(HWND hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam);


#endif

#endif//!__SYSMON_H__
