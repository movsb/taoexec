//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by window.rc
//
#define IDD_WINDOW                      101
#define IDB_BMP_BLANK                   102
#define IDB_BMP_FULL                    103
#define IDC_CURSOR_POINT                104
#define IDC_WNDICON                     1001
#define IDC_CHK_TOPMOST                 1002
#define IDC_CHK_MAXIMIZE                1003
#define IDC_CHK_MINIMIZE                1004
#define IDC_EDIT1                       1005
#define IDC_EDIT2                       1006
#define IDC_EDIT_CLASS                  1006
#define IDC_BTN_MAX                     1007
#define IDC_BTN_MIN                     1008
#define IDC_BTN_RESTORE                 1009
#define IDC_BTN_SHOW                    1010
#define IDC_EDIT3                       1011
#define IDC_EDIT_POS                    1012
#define IDC_EDIT_TITLE                  1013
#define IDC_STATIC_PICTURE              1014
#define IDC_PICTURE                     1014
#define IDC_EDIT_PROCESS                1015
#define IDC_CHK_HIDE                    1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
