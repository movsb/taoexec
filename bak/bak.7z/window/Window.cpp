#include <windows.h>
#include <string>

using namespace std;

#include "../nbsg/WindowBase.h"
#include "../nbsg/ListView.h"
#include "../nbsg/Button.h"
#include "../nbsg/EditBox.h"

#include "resource.h"
#include <TlHelp32.h>

HINSTANCE g_hInstDll;
AWindowBase* g_parent;

class AWindow:public AWindowBase
{
public:
	AWindow(AWindowBase* parent):
		m_bCapture(FALSE),
		m_hWndOld(NULL)
	{
		this->SetParent(parent);
		CreateDialogParam(g_hInstDll,MAKEINTRESOURCE(IDD_WINDOW),parent->GetHwnd(),(DLGPROC)GetWindowThunk(),0);
	}
	~AWindow()
	{
		this->DestroyWindow();
	}

public:
	INT_PTR DoDefault(UINT uMsg,WPARAM wParam,LPARAM lParam)
	{
		return 0;
	}

	INT_PTR OnLButtonDown(int key,int x,int y)
	{
		POINT ptScreen;
		RECT rcPicture;
		::GetWindowRect(m_hImage,&rcPicture);
		ptScreen.x = x;
		ptScreen.y = y;
		::ClientToScreen(this->GetHwnd(),&ptScreen);

		if(::PtInRect(&rcPicture,ptScreen)){
			m_bCapture = TRUE;
			SetCursor(m_hCurCross);
			::SendMessage(m_hImage,STM_SETIMAGE,IMAGE_BITMAP,(LPARAM)m_bmpBlank);
			SetCapture(this->GetHwnd());
		}
		return 0;
	}

	INT_PTR OnLButtonUp(int key,int x,int y)
	{
		if(m_bCapture){
			m_bCapture = FALSE;
			//m_hWndOld = NULL;
			SetCursor(LoadCursor(NULL,IDC_ARROW));
			::SendMessage(m_hImage,STM_SETIMAGE,IMAGE_BITMAP,(LPARAM)m_bmpFull);
			ReleaseCapture();
		}
		return 0;
	}
	INT_PTR OnMouseMove(int key,int x,int y)
	{
		if(m_bCapture){
			POINT pt;
			pt.x = x;
			pt.y = y;

			char text[2048]={0};

			DWORD dwPID;



			::ClientToScreen(this->GetHwnd(),&pt);
			
			HWND hCurrent = SmallestWindowFromPoint(&pt);
			if(hCurrent == m_hWndOld) return 0;

			GetWindowThreadProcessId(hCurrent,&dwPID);
			if(dwPID == m_dwPidThis) return 0;


			m_hWndOld = hCurrent;



			
			_snprintf(text,sizeof(text),"0x%08X",hCurrent);

			m_EditClass.SetWindowText(text);
			::GetWindowText(hCurrent,text,sizeof(text));
			m_EditTitle.SetWindowText(text);

			RECT rc;
			::GetWindowRect(hCurrent,&rc);
			_snprintf(text,sizeof(text),"(%d,%d,%d,%d) - (%d*%d)",
				rc.left,rc.top,rc.right,rc.bottom,rc.right-rc.left,rc.bottom-rc.top);
			m_EditPos.SetWindowText(text);


			m_EditProcess.SetWindowText(GetPathofPID(dwPID));

		}
		return 0;
	}
	INT_PTR OnKillFocus(HWND hWndFocus)
	{
		return this->OnLButtonUp(0,0,0);
	}

	INT_PTR OnInitDialog(HWND hWnd,HWND hWndFocus,LPARAM InitParam)
	{
		m_hWnd = hWnd;

		m_ChkTopmost	.AttachCtrl(this,IDC_CHK_TOPMOST);
		m_ChkHide		.AttachCtrl(this,IDC_CHK_HIDE);
		m_BtnMax		.AttachCtrl(this,IDC_BTN_MAX);
		m_BtnMin		.AttachCtrl(this,IDC_BTN_MIN);
		m_BtnRestore	.AttachCtrl(this,IDC_BTN_RESTORE);

		m_EditTitle		.AttachCtrl(this,IDC_EDIT_TITLE);
		m_EditClass		.AttachCtrl(this,IDC_EDIT_CLASS);
		m_EditPos		.AttachCtrl(this,IDC_EDIT_POS);
		m_EditProcess	.AttachCtrl(this,IDC_EDIT_PROCESS);


		m_hImage = GetDlgItem(this->GetHwnd(),IDC_PICTURE);
		m_hCurCross = ::LoadCursor(g_hInstDll,MAKEINTRESOURCE(IDC_CURSOR_POINT));
		m_bmpFull = ::LoadBitmap(g_hInstDll,MAKEINTRESOURCE(IDB_BMP_FULL));
		m_bmpBlank = ::LoadBitmap(g_hInstDll,MAKEINTRESOURCE(IDB_BMP_BLANK));

		::SendMessage(m_hImage,STM_SETIMAGE,IMAGE_BITMAP,(LPARAM)m_bmpFull);

		::GetWindowThreadProcessId(this->GetHwnd(),&m_dwPidThis);

		//SetTimer(hWnd,0,1000,NULL);

		return TRUE;
	}

	INT_PTR OnCommand(int codeNotify,int ctrlID,HWND hWndCtrl)
	{
		if(codeNotify==BN_CLICKED && hWndCtrl){
			assert(::IsWindow(m_hWndOld) && "AWindow::OnCommand()");
			if(ctrlID == m_BtnMax.GetCtrlID()){
				::ShowWindow(m_hWndOld,SW_MAXIMIZE);
				return 0;
			}else if(ctrlID ==m_BtnMin.GetCtrlID()){
				::ShowWindow(m_hWndOld,SW_MINIMIZE);
				return 0;
			}else if(ctrlID == m_BtnRestore.GetCtrlID()){
				::ShowWindow(m_hWndOld,SW_RESTORE);
				return 0;
			}else if(ctrlID == m_ChkTopmost.GetCtrlID()){
				::SetWindowPos(m_hWndOld,m_ChkTopmost.GetCheck()==BST_CHECKED?HWND_TOPMOST:HWND_NOTOPMOST,
					0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
				return 0;
			}else if(ctrlID == m_ChkHide.GetCtrlID()){
				BOOL bVisible = ::IsWindowVisible(m_hWndOld);
				::ShowWindow(m_hWndOld,bVisible?SW_HIDE:SW_SHOW);
				m_ChkHide.SetCheck(bVisible?BST_CHECKED:BST_UNCHECKED);
				return 0;
			}
		}
		return 0;
	}
	INT_PTR OnNotify(LPNMHDR phdr)
	{
		return 0;
	}

	INT_PTR OnSize(int width,int height)
	{
		return 0;
	}
	INT_PTR OnNull(LPARAM lParam)
	{
		ControlMessage* pcm = reinterpret_cast<ControlMessage*>(lParam);
		if(!pcm) return 0;

		return 0;
	}
private:
	HWND SmallestWindowFromPoint( POINT* ppt )
	{	
		RECT rect, rcTemp;
		HWND hParent, hWnd, hTemp;

		hWnd = WindowFromPoint( *ppt );
		if( hWnd != NULL )
		{
			::GetWindowRect( hWnd, &rect );
			hParent = ::GetParent( hWnd );

			// Has window a parent?
			if( hParent != NULL )
			{
				// Search down the Z-Order
				hTemp = hWnd;
				do{
					hTemp = GetWindow( hTemp, GW_HWNDNEXT );

					// Search window contains the point, hase the same parent, and is visible?
					::GetWindowRect( hTemp, &rcTemp );
					if(PtInRect(&rcTemp, *ppt) && ::GetParent(hTemp) == hParent && IsWindowVisible(hTemp))
					{
						// Is it smaller?
						if(((rcTemp.right - rcTemp.left) * (rcTemp.bottom - rcTemp.top)) < ((rect.right - rect.left) * (rect.bottom - rect.top)))
						{
							// Found new smaller window!
							hWnd = hTemp;
							::GetWindowRect(hWnd, &rect);
						}
					}
				}while( hTemp != NULL );
			}
		}

		return hWnd;
	}

	const char* GetPathofPID(DWORD dwPID)
	{
		static char path[MAX_PATH];

		char* p = "";

		PROCESSENTRY32 pe32;  
		// ��ʹ������ṹ֮ǰ�����������Ĵ�С  
		pe32.dwSize = sizeof(pe32);   

		// ��ϵͳ�ڵ����н�����һ������  
		HANDLE hProcessSnap = ::CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);  
		if(hProcessSnap == INVALID_HANDLE_VALUE)  
		{  
			//printf(" CreateToolhelp32Snapshot����ʧ�ܣ� \n");  
			return "";  
		}  

		// �������̿��գ�������ʾÿ�����̵���Ϣ  
		BOOL bMore = ::Process32First(hProcessSnap, &pe32);  
		while(bMore)  
		{  
			if(pe32.th32ProcessID == dwPID){
				strcpy(path,pe32.szExeFile);
				p=path;
				break;
			}

			bMore = ::Process32Next(hProcessSnap, &pe32);  
		}  

		// ��Ҫ���������snapshot����  
		::CloseHandle(hProcessSnap);  
		return p;  
	}


private:
	HWND m_hWndOld;
	BOOL m_bCapture;
	HWND m_hImage;
	HCURSOR m_hCurCross;
	HBITMAP m_bmpBlank;
	HBITMAP m_bmpFull;

	DWORD m_dwPidThis;

private:
	AButton		m_ChkTopmost;
	AButton		m_ChkHide;
	AButton		m_BtnMin;
	AButton		m_BtnMax;
	AButton		m_BtnRestore;

	AEditBox	m_EditTitle;
	AEditBox	m_EditClass;
	AEditBox	m_EditPos;
	AEditBox	m_EditProcess;
};

__declspec(dllexport) BOOL npInit(AWindowBase* parent)
{
	g_parent = parent;

	AWindow* pmw = new AWindow(parent);

	ControlMessage cm = {0};
	cm.self = NULL;
	cm.uMsg = WM_USER+1;
	cm.wParam = (WPARAM)pmw;
	cm.lParam = LPARAM("���ڹ���");
	pmw->NotifyParent(&cm);

	return TRUE;

}

__declspec(dllexport) void npAbout()
{
	//MessageBox(g_parent->GetHwnd(),"Window���ڹ��� ����Ѽ���~","Window",MB_OK);
}


BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	g_hInstDll = hinstDLL;
	return TRUE;
}
