#ifndef __PSWWND_H__
#define __PSWWND_H__

#include "../nbsg/WindowBase.h"
#include "../nbsg/Button.h"
#include "../nbsg/EditBox.h"

#include "libs/md5.h"
#include "libs/aes.h"

extern const char* g_data;

class APswWnd:public AWindowBase
{
public:
	APswWnd(AWindowBase* parent,unsigned char* keytext,unsigned char* encdata,UCHAR oldkey[32]);
	~APswWnd();

public:
	INT_PTR DoDefault(UINT uMsg,WPARAM wParam,LPARAM lParam);
	INT_PTR OnClose();
	INT_PTR OnInitDialog(HWND hWnd,HWND hWndFocus,LPARAM InitParam);
	INT_PTR OnCommand(int codeNotify,int ctrlID,HWND hWndCtrl);

private:
	AButton		m_BtnOk;
	AButton		m_BtnCancel;

	AEditBox	m_EditOld;
	AEditBox	m_EditNew;
	AEditBox	m_EditConfirm;

private:
	unsigned char* m_keytext;
	unsigned char* m_encdata;
	unsigned char* m_oldkey;
	BOOL m_bHasPassword;
};

class ARequestPassword:public AWindowBase
{
public:
	ARequestPassword(AWindowBase* parent,UCHAR key[32],UCHAR data[16]);
	~ARequestPassword();

public:
	INT_PTR DoDefault(UINT uMsg,WPARAM wParam,LPARAM lParam);
	INT_PTR OnClose();
	INT_PTR OnInitDialog(HWND hWnd,HWND hWndFocus,LPARAM InitParam);
	INT_PTR OnCommand(int codeNotify,int ctrlID,HWND hWndCtrl);

private:
	UCHAR* m_pkey;
	UCHAR* m_pdata;

private:
	AEditBox	m_editPsw;
	AButton		m_btnOk;
	AButton		m_btnCancel;
};

class AEnctypt
{
public:
	AEnctypt(const char* key,size_t len)
	{
		md5_state_t m_state;
		md5_byte_t m_digest[16];
		md5_byte_t m_md5str[33];



		md5_init(&m_state);
		md5_append(&m_state,(md5_byte_t*)key,len);
		md5_finish(&m_state,&m_digest[0]);

		for(int count=0;count<16;count++){
			sprintf((char*)&m_md5str[count*2], "%02X", (unsigned char)m_digest[count]);
		}

		SetKey(&m_md5str[0]);
		
	}
	AEnctypt(const unsigned char* key)
	{
		SetKey((md5_byte_t*)key);
	}
	~AEnctypt()
	{

	}
	void Encrypt(unsigned char* pdata,size_t size)
	{
		assert(size%16==0 && "AEncrypt::Encrypt()");
		size_t nblocks = size/16;
		size_t it;

		for(it=0; it<nblocks; it++){
			aes_encrypt(&m_ctx,pdata+it*16);
		}
	}
	void Decrypt(unsigned char* pdata,size_t size)
	{
		assert(size%16==0 && "AEncrypt::Decrypt()");

		size_t nblocks = size/16;
		size_t it;

		for(it=0; it<nblocks; it++){
			aes_decrypt(&m_ctx,pdata+it*16);
		}
	}
	void GetMd5(char data[32])
	{
		memcpy(&data[0],&m_md5str[0],32);
	}
	static const char* GetOriginalData()
	{
		return g_data;
	}
	static BOOL Need(UCHAR* pdata)
	{
		return memcmp(pdata,g_data,16)!=0;
	}
private:
	void SetKey(md5_byte_t str[32])
	{
		aes_set_key(&m_ctx,(unsigned char*)str,256);

		memcpy(&m_md5str[0],&str[0],32);
	}

private:
	aes_context m_ctx;
	md5_byte_t m_md5str[32];
};

#endif//!__PSWWND_H__
