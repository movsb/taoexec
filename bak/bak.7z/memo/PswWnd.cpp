#include "resource.h"
#include "PswWnd.h"

#include "libs/aes.h"
#include "libs/md5.h"

extern HINSTANCE g_hInstDll;

const char* g_data = "Ů������Ů������";

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

ARequestPassword::ARequestPassword(AWindowBase* parent,UCHAR key[32],UCHAR data[16])
{
	this->SetParent(parent);
	m_pkey = key;
	m_pdata = data;
	m_ModalDialogResultCode=::DialogBox(g_hInstDll,MAKEINTRESOURCE(IDD_REQPSW),GetParent()->GetHwnd(),DLGPROC(GetWindowThunk()));
}
ARequestPassword::~ARequestPassword()
{

}

INT_PTR ARequestPassword::DoDefault(UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	return 0;
}

INT_PTR ARequestPassword::OnClose()
{
	this->EndDialog(FALSE);
	return 0;
}

INT_PTR ARequestPassword::OnInitDialog(HWND hWnd,HWND hWndFocus,LPARAM InitParam)
{
	m_hWnd = hWnd;

	m_editPsw	.AttachCtrl(this,IDC_EDIT_REQPSW);
	m_btnOk		.AttachCtrl(this,IDOK);
	m_btnCancel	.AttachCtrl(this,IDCANCEL);

	this->CenterWindow(GetParent()->GetHwnd());
	this->ShowWindow(SW_SHOWNORMAL);

	m_editPsw.SetFocus();

	return FALSE;
}
INT_PTR ARequestPassword::OnCommand(int codeNotify,int ctrlID,HWND hWndCtrl)
{
	if(codeNotify==BN_CLICKED && hWndCtrl){
		if(ctrlID == m_btnOk.GetCtrlID()){
			UCHAR tdata[16];
			std::string strPsw = m_editPsw.GetWindowText();
			memcpy(tdata,m_pdata,16);

			AEnctypt enc(strPsw.c_str(),strPsw.size());
			enc.Decrypt(tdata,16);
			if(memcmp(g_data,tdata,16) == 0){//������ȷ
				//memcpy(m_pdata,g_data,16);
				//enc.GetMd5((char*)m_pkey);
				EndDialog(TRUE);
				return 0;
			}else{
				MessageBox(TEXT("����������벻��ȷ!"),NULL,MB_ICONEXCLAMATION);
				m_editPsw.SetFocus();
				return 0;
			}

		}else if(ctrlID == m_btnCancel.GetCtrlID()){
			EndDialog(FALSE);
			return 0;
		}
	}
	return 0;
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////


APswWnd::APswWnd(AWindowBase* parent,unsigned char* keytext,unsigned char* encdata,UCHAR oldkey[32])
{
	m_keytext = keytext;
	m_encdata = encdata;
	m_oldkey = oldkey;

	this->SetParent(parent);
	m_ModalDialogResultCode=::DialogBox(g_hInstDll,MAKEINTRESOURCE(IDD_PASSWORD),parent->GetHwnd(),(DLGPROC)GetWindowThunk());
}

APswWnd::~APswWnd()
{

}

INT_PTR APswWnd::DoDefault(UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	return 0;
}

INT_PTR APswWnd::OnInitDialog(HWND hWnd,HWND hWndFocus,LPARAM InitParam)
{
	m_hWnd = hWnd;

	m_BtnOk			.AttachCtrl(this,IDC_BTN_OK);
	m_BtnCancel		.AttachCtrl(this,IDC_BTN_CANCEL);
	
	m_EditOld		.AttachCtrl(this,IDC_EDIT_OLD);
	m_EditNew		.AttachCtrl(this,IDC_EDIT_NEW);
	m_EditConfirm	.AttachCtrl(this,IDC_EDIT_CONFIRM);

	m_EditOld		.SubClass();
	m_EditNew		.SubClass();
	m_EditConfirm	.SubClass();

	this->CenterWindow(GetParent()->GetHwnd());
	this->ShowWindow(SW_SHOWNORMAL);

	m_bHasPassword = memcmp(g_data,m_encdata,16)!=0;

	return TRUE;
}

INT_PTR APswWnd::OnCommand(int codeNotify,int ctrlID,HWND hWndCtrl)
{
	if(codeNotify == BN_CLICKED && hWndCtrl){
		if(ctrlID == m_BtnCancel.GetCtrlID()){
			this->EndDialog(FALSE);
			return 0;
		}else if(ctrlID == m_BtnOk.GetCtrlID()){
			if(m_bHasPassword==FALSE){
				if(m_EditOld.GetWindowTextLength()){
					MessageBox(TEXT("ԭ���벻��ȷ!"),TEXT(""),MB_ICONERROR);
					return 0;
				}
			}else{
				if(m_EditOld.GetWindowTextLength()==0){
					MessageBox(TEXT("ԭ���벻��Ϊ��!"),TEXT(""),MB_ICONERROR);
					return 0;
				}
			}

			if(m_EditNew.GetWindowTextLength() != m_EditConfirm.GetWindowTextLength()){
				MessageBox(TEXT("������ĳ��Ȳ�һ��!"),TEXT(""),MB_ICONEXCLAMATION);
				return 0;
			}

			std::string strNew = m_EditNew.GetWindowText();
			std::string strConfirm = m_EditConfirm.GetWindowText();
			std::string strOld = m_EditOld.GetWindowText();

			if(memcmp(strNew.c_str(),strConfirm.c_str(),strNew.size()) != 0){
				MessageBox(TEXT("������������벻һ��, ����������!"),NULL,MB_ICONEXCLAMATION);
				return 0;
			}

			if(m_bHasPassword){//ԭ��������
				//������֤
				unsigned char tmpdata[16];
				memcpy(tmpdata,m_encdata,16);

				AEnctypt enc(strOld.c_str(),strOld.size());
				enc.Decrypt(tmpdata,16);
				if(memcmp(tmpdata,g_data,16)!=0){
					MessageBox(TEXT("�������ԭ��������,��ȷ��!"),NULL,MB_ICONERROR);
					return 0;
				}else{
					memcpy(m_encdata,tmpdata,16);//ûʹ��
				}
				//������ȷ�������Ѿ�����
				//����ԭ����
				enc.GetMd5((char*)m_oldkey);

				if(strNew.size() == 0){//������Ϊ��
					*m_keytext = '\0';
					memcpy(m_encdata,g_data,16);
					MessageBox(TEXT("������ɾ��!"),"",MB_ICONINFORMATION);
					this->EndDialog(TRUE);
					return 0;
				}else{//�����벻Ϊ��,�ı����봮
					AEnctypt enc(strNew.c_str(),strNew.size());
					enc.GetMd5((char*)m_keytext);
					//enc.Encrypt(m_encdata,16);
					MessageBox(TEXT("�Ѹ�������!"),TEXT(""),MB_ICONINFORMATION);
					this->EndDialog(TRUE);
					return 0;
				}
			}else{//ԭ��û������
				if(strNew.size()){
					AEnctypt enc(strNew.c_str(),strNew.size());
					enc.GetMd5((char*)m_keytext);
					//enc.Encrypt(m_encdata,16);
					MessageBox(TEXT("���趨����!"),TEXT(""),MB_ICONINFORMATION);
					this->EndDialog(TRUE);
				}else{
					//ԭ����û������,����Ҫ��ʲô
					*m_keytext = '\0';//�˾�Ҳ����
					this->EndDialog(FALSE);
				}
				
				return 0;
			}
		}
	}
	return 0;
}

INT_PTR APswWnd::OnClose()
{
	this->EndDialog(FALSE);
	return 0;
}
