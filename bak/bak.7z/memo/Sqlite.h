#include <windows.h>

#include "../nbsg/sqlite3/sqlite3.h"

class ADataBase
{
public:
	ADataBase();
	~ADataBase();

public:
	BOOL OpenDB(const char* db);
	BOOL CloseDB();

public:
#pragma pack(push,1)
	struct MemoEntry
	{
		int version;
		char idx[11];
		char name[128];
		unsigned char key[32];
		unsigned char data[16];
		int remain;
		MemoEntry* next;
	};
#pragma pack(pop)
public:
	BOOL GetMemoEntries(MemoEntry** ppMemoEntry,size_t* pSize);
	BOOL GetMemo(const char* idx,unsigned char** ppData,size_t* psize);
	BOOL SaveMemo(char* idx,const unsigned char* hdr,size_t hdrsize,unsigned char* pData,size_t size);
	BOOL SaveMemoHdr(char* idx,const unsigned char* phdr,size_t hdrsize);
	BOOL DeleteMemo(const char* idx);

private:
	sqlite3* m_db;
	sqlite3_stmt* m_pStmt;
	char* m_zErr;
};
