#include <windows.h>
#include <string>

using namespace std;

#include "../nbsg/WindowBase.h"
#include "../nbsg/ListView.h"
#include "../nbsg/Button.h"
#include "../nbsg/EditBox.h"

#include "PswWnd.h"
#include "Sqlite.h"
#include "resource.h"

HINSTANCE g_hInstDll;
AWindowBase* g_parent;

class AMemoWindow:public AWindowBase
{
public:
	AMemoWindow(AWindowBase* parent):
		m_MemoEntry(NULL),
		m_CurrentIndexofMemo(-1)
	{
		this->SetParent(parent);
		CreateDialogParam(g_hInstDll,MAKEINTRESOURCE(IDD_MEMO),parent->GetHwnd(),(DLGPROC)GetWindowThunk(),0);
	}
	~AMemoWindow()
	{
		this->DestroyWindow();
	}

public:
	INT_PTR DoDefault(UINT uMsg,WPARAM wParam,LPARAM lParam)
	{
		return 0;
	}

	INT_PTR OnInitDialog(HWND hWnd,HWND hWndFocus,LPARAM InitParam)
	{
		m_hWnd = hWnd;

		m_MemoList.		AttachCtrl(this,IDC_MEMO_LISTMEMO);

		m_ButtonNew.	AttachCtrl(this,IDC_MEMO_NEWMEMO);
		m_ButtonSave.	AttachCtrl(this,IDC_MEMO_SAVEMEMO);
		m_ButtonDelete.	AttachCtrl(this,IDC_MEMO_DELMEMO);
		m_ButtonPsw.	AttachCtrl(this,IDC_MEMO_CHGPSW);

		m_ButtonSave	.SetImage("skin/���汸��.bmp");
		m_ButtonPsw		.SetImage("skin/��������.bmp");
		m_ButtonNew		.SetImage("skin/�½�����.bmp");
		m_ButtonDelete	.SetImage("skin/ɾ������.bmp");

		m_MemoContent.	AttachCtrl(this,IDC_MEMO_EDITCONTENT);
		m_MemoContent.SubClass();

		m_DataBase.OpenDB("memo.db");

		InitListView();
		//this->ShowWindow(SW_SHOW);

		ADataBase::MemoEntry* pme = NULL;
		size_t size;
		if(m_DataBase.GetMemoEntries(&pme,&size)){
			m_MemoEntry = pme;
			ADataBase::MemoEntry* pit = pme;
			while(pit){
				LV_ITEM lvi = {0};
				lvi.mask = LVIF_TEXT|LVIF_PARAM;
				lvi.pszText = pit->name;
				lvi.lParam = (LPARAM)pit;
				m_MemoList.InsertItem(&lvi);
				
				pit = pit->next;
			}
		}
		
		return TRUE;
	}

	INT_PTR OnCommand(int codeNotify,int ctrlID,HWND hWndCtrl)
	{
		if(codeNotify == BN_CLICKED && hWndCtrl){
			if(ctrlID == m_ButtonSave.GetCtrlID()){
				if(m_MemoContent.GetModify() == FALSE){
					MessageBox("û�����޸�, ����Ҫ����!","",MB_OK|MB_ICONINFORMATION);
					return SetDlgResult(TRUE);
				}
				//���ݷ������޸�,m_CurrentIndexofMemo��¼�˵�ǰ������һ��LVITEM
				if(m_CurrentIndexofMemo == -1){
					MessageBox("û�д��κα���, ���½�����!",NULL,MB_OK);
					return SetDlgResult(FALSE);
				}

				assert(m_CurrentIndexofMemo < m_MemoList.GetItemCount());

				ADataBase::MemoEntry* pme = (ADataBase::MemoEntry*)m_MemoList.GetItemLParam(m_CurrentIndexofMemo);

				BOOL bNeedPsw = AEnctypt::Need(pme->data);

				if(bNeedPsw){
					ARequestPassword rp(this,pme->key,pme->data);
					int dlgcode = rp.GetDlgCode();
					if(dlgcode == FALSE) return SetDlgResult(FALSE);
				}

				string content = m_MemoContent.GetWindowText();
				size_t size = content.size()+1;
				UCHAR* pdata = (UCHAR*)content.c_str();
				EncryptMemoData(&pdata,&size,pme);
				
				if(m_DataBase.SaveMemo(pme->idx,(const unsigned char*)pme,sizeof(*pme),pdata,size)){
					delete[] pdata;
					m_MemoContent.SetModify(FALSE);
					MessageBox("����ɹ�!","",MB_ICONINFORMATION);
					return SetDlgResult(TRUE);
				}else{
					delete[] pdata;
					MessageBox("����ʧ��!","",MB_ICONINFORMATION);
					return SetDlgResult(FALSE);
				}
			}else if(ctrlID == m_ButtonNew.GetCtrlID()){
				BOOL bEmptyEdit =TRUE;
				if(m_MemoContent.GetModify() == TRUE){
					if(MessageBox("�½�֮ǰ���浱ǰ�������޸���?","",MB_ICONQUESTION|MB_YESNO) == IDYES){
						if(m_CurrentIndexofMemo != -1){
							if(this->SendMessage(WM_COMMAND,MAKEWPARAM(m_ButtonSave.GetCtrlID(),BN_CLICKED),(LPARAM)m_ButtonSave.GetHwnd()) == FALSE){
								MessageBox("�򱣴�ʧ���½�����δ�ܼ���!",NULL,MB_ICONERROR);
								return SetDlgResult(FALSE);
							}
						}else{
							bEmptyEdit = FALSE;
						}
					}
				}

				//�ɹ�����,������һ��
				ADataBase::MemoEntry* pme = new ADataBase::MemoEntry;
				memset(pme,0,sizeof(*pme));
				pme->version = 1;
				memcpy(pme->data,AEnctypt::GetOriginalData(),16);
				pme->idx[0] = '\0';
				strncpy(pme->name,"<�±���>",sizeof(pme->name));
				
				pme->next = m_MemoEntry;
				m_MemoEntry = pme;

				LVITEM lvi = {0};
				lvi.mask = LVIF_TEXT|LVIF_PARAM;
				lvi.pszText = pme->name;
				lvi.lParam = (LPARAM)pme;
				lvi.iItem = 0;
				m_CurrentIndexofMemo = m_MemoList.InsertItem(&lvi);
				
				//���ĵ�ǰѡ�е��µı���
				m_MemoList.SetItemState(-1,0,LVIS_SELECTED);
				m_MemoList.SetItemState(m_CurrentIndexofMemo,LVIS_SELECTED,LVIS_SELECTED);

				if(bEmptyEdit) m_MemoContent.SetWindowText("");

				return SetDlgResult(TRUE);

			}else if(ctrlID == m_ButtonDelete.GetCtrlID()){
				int isel = m_MemoList.GetNextItem(-1,LVNI_SELECTED);
				if(isel == -1){
					MessageBox("û��ѡ���κ���!",NULL,MB_OK);
					return SetDlgResult(FALSE);
				}

				ADataBase::MemoEntry* pme = (ADataBase::MemoEntry*)m_MemoList.GetItemLParam(isel);

				if(pme->idx[0] == '\0'){//˵�����½�����
					m_MemoList.DeleteItem(isel);

					int cmp = m_CurrentIndexofMemo-isel;
					if(cmp == 0){//���ɾ�����ǵ�ǰѡ�е���
						m_CurrentIndexofMemo = -1;
						m_MemoContent.SetWindowText("");
					}else if(cmp < 0){//ɾ�����ǵ�ǰ������,��Ӱ�쵱ǰ����

					}else if(cmp > 0){//ɾ�����ǵ�ǰ��ǰ�����
						m_CurrentIndexofMemo -- ;
					}

					return SetDlgResult(TRUE);
				}else{
					//�ж��Ƿ���Ҫ����
					BOOL bNeedPsw = AEnctypt::Need(pme->data);

					if(bNeedPsw){
						ARequestPassword rp(this,pme->key,pme->data);
						int dlgcode = rp.GetDlgCode();
						if(dlgcode == FALSE) return SetDlgResult(FALSE);
					}

					if(MessageBox(pme->name,"ȷʵҪɾ��?",MB_ICONQUESTION|MB_YESNO)==IDYES){
						if(m_DataBase.DeleteMemo(pme->idx)){
							m_MemoList.DeleteItem(isel);

							int cmp = m_CurrentIndexofMemo-isel;
							if(cmp == 0){//���ɾ�����ǵ�ǰѡ�е���
								m_CurrentIndexofMemo = -1;
								m_MemoContent.SetWindowText("");
							}else if(cmp < 0){//ɾ�����ǵ�ǰ������,��Ӱ�쵱ǰ����

							}else if(cmp > 0){//ɾ�����ǵ�ǰ��ǰ�����
								m_CurrentIndexofMemo -- ;
							}

							return SetDlgResult(TRUE);
						}
					}
					return SetDlgResult(FALSE);
				}
			}else if(ctrlID == m_ButtonPsw.GetCtrlID()){
				int isel = m_MemoList.GetNextItem(-1,LVNI_SELECTED);
				if(isel == -1){
					MessageBox("û��ѡ���κ���!",NULL,MB_OK);
					return SetDlgResult(FALSE);
				}

				ADataBase::MemoEntry* pme = (ADataBase::MemoEntry*)m_MemoList.GetItemLParam(isel);

				UCHAR oldKey[32];
				if(!ChangePassword(pme->key,pme->data,oldKey))
					return SetDlgResult(FALSE);

				ADataBase::MemoEntry me;
				memcpy(&me,pme,sizeof(me));//��ԭ�������,���������
				memcpy(&me.key,oldKey,32); //���ԭ��û������,��oldkeyΪ��Ч����

				//����޸��������ǵ�ǰ�򿪵�, ���������µ����ݿ�
				if(isel != m_CurrentIndexofMemo){
					UCHAR* pData = NULL;		//ԭʼ����
					UCHAR* pEncData = NULL;		//�¼��ܺ������
					size_t size;
					if(m_DataBase.GetMemo(pme->idx,&pData,&size)){
						DecryptMemoData(pData,&size,&me);//sizeΪʵ�ʴ�С
						pEncData = pData;

						AEnctypt enc(pme->key);
						enc.Encrypt(pme->data,16);
						EncryptMemoData(&pEncData,&size,pme);
						delete[] pData;//ԭʼ����

						//�������
						memset(pme->key,0,sizeof(pme->key));
						if(m_DataBase.SaveMemo(pme->idx,(UCHAR*)pme,sizeof(*pme),pEncData,size)){
							delete[] pEncData;
							MessageBox("�����޸ĳɹ�!","",MB_ICONINFORMATION);
							return SetDlgResult(TRUE);
						}else{
							delete[] pEncData;
							MessageBox("�����޸�ʧ��!","",MB_ICONINFORMATION);
							return SetDlgResult(FALSE);
						}
					}else{
						MessageBox("��ȡ����ʱ����!",NULL,MB_ICONERROR);
					}
				}else{
					//���ڱ༭��ǰ�޸��������,
					m_MemoContent.SetModify(TRUE);

//					if(AEnctypt::Need(pme->data)==FALSE){
						AEnctypt enc(pme->key);
						enc.Encrypt(pme->data,16);
//					}
				}
				return 0;
			}//if ctrl
		}
		return 0;
	}

	INT_PTR OnNotify(LPNMHDR phdr)
	{
		if(phdr->idFrom == m_MemoList.GetCtrlID()){
			switch(phdr->code)
			{
			case NM_DBLCLK:
				{
					int isel = m_MemoList.GetNextItem(-1,LVNI_SELECTED);
					if(isel == -1) return 0;

					if(m_MemoContent.GetModify() == TRUE){
						int ret=MessageBox("�ڴ���������֮ǰ���浱ǰ�������޸���?","",MB_ICONQUESTION|MB_YESNOCANCEL);
						if(ret == IDYES){
							if(this->SendMessage(WM_COMMAND,MAKEWPARAM(m_ButtonSave.GetCtrlID(),BN_CLICKED),(LPARAM)m_ButtonSave.GetHwnd()) == FALSE){
								//MessageBox("�򱣴�ʧ���½�����δ�ܼ���!",NULL,MB_ICONERROR);
								return SetDlgResult(FALSE);
							}
						}else if(ret==IDCANCEL){
							return SetDlgResult(FALSE);
						}
					}

					ADataBase::MemoEntry* pme = (ADataBase::MemoEntry*)m_MemoList.GetItemLParam(isel);

					if(pme->idx[0]=='\0'){//�½���
						//���浱ǰѡ��, һ��Ҫ�������Ǹ��ж�֮�����޸�,��Ϊ�����ʱ��Ҫ�õ����ֵ
						m_CurrentIndexofMemo = isel;
						m_MemoContent.SetWindowText("");
						m_MemoContent.SetFocus();
						return 0;
					}

					//�ж��Ƿ���Ҫ����
					BOOL bNeedPsw = AEnctypt::Need(pme->data);

					if(bNeedPsw){
						ARequestPassword rp(this,pme->key,pme->data);
						int dlgcode = rp.GetDlgCode();
						if(dlgcode == FALSE) return 0;
					}

					//���浱ǰѡ��, һ��Ҫ�������Ǹ��ж�֮�����޸�,��Ϊ�����ʱ��Ҫ�õ����ֵ
					m_CurrentIndexofMemo = isel;

					//������ȷ
					UCHAR* pData = NULL;
					size_t size;
					if(m_DataBase.GetMemo(pme->idx,&pData,&size)){
						DecryptMemoData(pData,&size,pme);
						m_MemoContent.SetWindowText((char*)pData);
					}else{
						MessageBox("��ȡ����ʱ����!",NULL,MB_ICONERROR);
					}
					m_MemoContent.SetFocus();
					return 0;
				}
			case LVN_ENDLABELEDIT:
				{
					NMLVDISPINFO* pdi = (NMLVDISPINFO*)phdr;
					if(pdi->item.pszText != NULL){
						if(strchr(pdi->item.pszText,'\'')){
							MessageBox("�㲻Ӧ���������а����������ַ�!",NULL,MB_ICONEXCLAMATION);
							return SetDlgResult(FALSE);
						}else{
							//��ʱ�������½���, Ҳ�п������Ѿ����ڵ�����,����Ѿ���������µ����ݿ�
							ADataBase::MemoEntry* pme = (ADataBase::MemoEntry*)m_MemoList.GetItemLParam(pdi->item.iItem);
							if(pme->idx[0] != '\0'){
								strncpy(pme->name,pdi->item.pszText,sizeof(pme->name));
								if(m_DataBase.SaveMemoHdr(pme->idx,(const unsigned char*)pme,sizeof(ADataBase::MemoEntry))){
									return SetDlgResult(TRUE);
								}else{
									return SetDlgResult(FALSE);
								}
							}else{
								return SetDlgResult(TRUE);
							}
						}
					}
					return 0;
				}
			case NM_CUSTOMDRAW:
				{
					LPNMLVCUSTOMDRAW plcd = (LPNMLVCUSTOMDRAW)phdr;
					switch(plcd->nmcd.dwDrawStage)
					{
					case CDDS_PREPAINT:
						return SetDlgResult(CDRF_NOTIFYITEMDRAW);
					case CDDS_ITEMPREPAINT:
						{
							ADataBase::MemoEntry* pme = reinterpret_cast<ADataBase::MemoEntry*>(plcd->nmcd.lItemlParam);
							if(pme->idx[0] == '\0'){
								plcd->clrText = RGB(255,0,0);
								plcd->clrTextBk = RGB(255,255,255);
							}else{
								plcd->clrText = RGB(0,0,0);
								plcd->clrTextBk = RGB(255,255,255);
							}
							return SetDlgResult(CDRF_NEWFONT);
						}
					}
					return SetDlgResult(CDRF_DODEFAULT);
				}
			}//switch
			return 0;
		}//phdr->id == list
		return 0;
	}

	INT_PTR OnSize(int width,int height)
	{
		RECT rcListWindow,rcListCient;
		m_MemoList.GetWindowRect(&rcListWindow);
		m_MemoList.GetClientRect(&rcListCient);

		RECT rcEditWindow,rcEditClient;
		m_MemoContent.GetWindowRect(&rcEditWindow);
		m_MemoContent.GetClientRect(&rcEditClient);

		RECT rcDlg;
		this->GetWindowRect(&rcDlg);

		int list_offset_x = rcListWindow.left-rcDlg.left;
		int list_offset_y = rcListWindow.top-rcDlg.top;

		int edit_offset_x =rcEditWindow.left-rcDlg.left;
		int edit_offset_y = rcEditWindow.top-rcDlg.top;
		
		m_MemoList.SetWindowPos(list_offset_x,list_offset_y,rcListWindow.right-rcListWindow.left,height-list_offset_y-10);
		m_MemoContent.SetWindowPos(edit_offset_x,edit_offset_y,width-edit_offset_x-10,height-edit_offset_y-10);

		return 0;
	}
	INT_PTR OnNull(LPARAM lParam)
	{
		ControlMessage* pcm = reinterpret_cast<ControlMessage*>(lParam);
		if(!pcm) return 0;

		if(pcm->self = &m_MemoContent){
			if(pcm->uMsg != WM_CONTEXTMENU){
				return SetDlgResult(pcm->self->DoDefault(pcm));
			}
		}
		return 0;
	}

private:
	void InitListView()
	{
		LVCOLUMN lvc = {0};
		lvc.mask = LVCF_TEXT|LVCF_WIDTH;
		lvc.pszText = "����";
		lvc.cx = 200;
		m_MemoList.InsertColumn(0,&lvc);

		m_MemoList.SetExtendedListViewStyle(m_MemoList.GetExtendedListViewStyle()|LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
		m_MemoList.SetStyle(m_MemoList.GetStyle()|LVS_SINGLESEL);
	}

	BOOL RequestPassword(UCHAR key[32],UCHAR encdata[16])
	{
		ARequestPassword rp(this,key,encdata);
		int dlgcode = rp.GetDlgCode();
		return dlgcode == TRUE;
	}

	BOOL ChangePassword(UCHAR key[32],UCHAR encdata[16],UCHAR oldkey[32])
	{
		APswWnd pw(this,key,encdata,oldkey);
		int dlgcode = pw.GetDlgCode();
		return dlgcode == TRUE;
	}

	BOOL EncryptMemoData(IN OUT UCHAR** ppdata,IN OUT size_t* psize,ADataBase::MemoEntry* pme)
	{
		size_t size=*psize;
		size_t remain = size%16;

		remain = remain?16-remain:0;

		size_t totalsize = size + remain;

		UCHAR* tdata = new UCHAR[totalsize];
		memset(tdata,0,totalsize);
		memcpy(tdata,*ppdata,size);

		//�ж��Ƿ���Ҫ����
		if(AEnctypt::Need(pme->data)){
			AEnctypt enc(pme->key);
			enc.Encrypt(tdata,totalsize);
		}

		*ppdata = tdata;
		*psize = totalsize;

		pme->remain = remain;

		return TRUE;
	}

	BOOL DecryptMemoData(UCHAR* pdata,size_t* psize,ADataBase::MemoEntry* pme)
	{
		assert(*psize%16==0 && "DecryptMemoData()");
		if(AEnctypt::Need(pme->data)){
			AEnctypt dec(pme->key);
			dec.Decrypt(pdata,*psize);
		}

		*psize = *psize - pme->remain;

		return TRUE;
	}

private:
	AListView m_MemoList;
	AButton   m_ButtonNew;
	AButton   m_ButtonDelete;
	AButton   m_ButtonSave;
	AButton	  m_ButtonPsw;
	AEditBox  m_MemoContent;
	ADataBase m_DataBase;
	ADataBase::MemoEntry* m_MemoEntry;

	int m_CurrentIndexofMemo;
};

__declspec(dllexport) BOOL npInit(AWindowBase* parent)
{
	g_parent = parent;

	AMemoWindow* pmw = new AMemoWindow(parent);

	ControlMessage cm = {0};
	cm.self = NULL;
	cm.uMsg = WM_USER+1;
	cm.wParam = (WPARAM)pmw;
	cm.lParam = LPARAM("����");
	pmw->NotifyParent(&cm);

	return TRUE;

}

__declspec(dllexport) void npAbout()
{

}


BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	g_hInstDll = hinstDLL;
	return TRUE;
}
