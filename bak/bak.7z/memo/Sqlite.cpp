#include <string>
#include <sstream>

using namespace std;

#include "../nbsg/sqlite3/sqlite3.h"
#pragma comment(lib,"../nbsg/sqlite3/sqlite3.lib")

#include "../nbsg/Str.h"
#include "Sqlite.h"
#include <assert.h>

ADataBase::ADataBase()
{

}
ADataBase::~ADataBase()
{

}

//db����Ҫһ����UTF-8
BOOL ADataBase::OpenDB(const char* db)
{
	if(sqlite3_open(AStr(db,false).toUtf8(),&m_db) != SQLITE_OK){
		return FALSE;
	}else{
		string s = "create table if not exists memo (id integer primary key,memo_hdr blob,memo_data blob);";
		if(sqlite3_exec(m_db,s.c_str(),NULL,NULL,&m_zErr) != SQLITE_OK){
			sqlite3_free(m_zErr);
			return FALSE;
		}
		return TRUE;
	}
}

BOOL ADataBase::CloseDB()
{
	if(sqlite3_close(m_db) == SQLITE_OK){
		m_db = NULL;
		return TRUE;
	}else{
		return FALSE;
	}
}

BOOL ADataBase::GetMemo(const char* idx,unsigned char** ppData,size_t* psize)
{
	string sql = "select id,memo_data from memo where id=";
	sql += idx;
	
	if(sqlite3_prepare(m_db,sql.c_str(),-1,&m_pStmt,NULL) == SQLITE_OK){
		switch(sqlite3_step(m_pStmt))
		{
		case SQLITE_ROW:
			{
				//id(0) + data(1)
				size_t size = sqlite3_column_bytes(m_pStmt,1);
				unsigned char* pd = new unsigned char[size];
				memcpy(pd,sqlite3_column_blob(m_pStmt,1),size);
				*ppData = pd;
				*psize = size;
				sqlite3_finalize(m_pStmt);
				return TRUE;
			}
		case SQLITE_DONE:
			{
				break;
			}
		default:
			break;
		}
		sqlite3_finalize(m_pStmt);
		return FALSE;
	}else{
		::MessageBox(NULL,sqlite3_errmsg(m_db),NULL,MB_ICONERROR);
		return FALSE;
	}
}

//idx - ���������,�µ�idx�᷵�ص�����
BOOL ADataBase::SaveMemo(char* idx,const unsigned char* hdr,size_t hdrsize,unsigned char* pData,size_t size)
{
	string sql;
	BOOL ret=FALSE;
	BOOL bNew;

	bNew = idx?idx[0]=='\0':TRUE;

	if(bNew){
		sql = "insert into memo (memo_hdr,memo_data) values (\?,\?);";
	}else{
		sql = "update memo set memo_hdr=\?,memo_data=\? where id=";
		sql += idx;
	}

	AStr asql(sql.c_str(),false);
	if(sqlite3_prepare(m_db,asql.toUtf8(),-1,&m_pStmt,NULL) == SQLITE_OK){
		if(sqlite3_bind_blob(m_pStmt,1,hdr,hdrsize,NULL) == SQLITE_OK &&
			sqlite3_bind_blob(m_pStmt,2,pData,size,NULL) == SQLITE_OK)
		{
			if(sqlite3_step(m_pStmt) == SQLITE_DONE){
				if(bNew){
					int id = (int)sqlite3_last_insert_rowid(m_db);
					sprintf(idx,"%u",id);
				}
				ret = TRUE;
			}
		}
		sqlite3_finalize(m_pStmt);
	}
	if(ret == FALSE){
		MessageBox(NULL,sqlite3_errmsg(m_db),NULL,MB_OK);
	}
	return ret;
}

BOOL ADataBase::SaveMemoHdr(char* idx,const unsigned char* phdr,size_t hdrsize)
{
	string sql;
	sql = "update memo set memo_hdr=\? where id=";
	sql += idx;

	BOOL bRet = FALSE;
	if(sqlite3_prepare(m_db,sql.c_str(),-1,&m_pStmt,NULL) == SQLITE_OK){
		if(sqlite3_bind_blob(m_pStmt,1,phdr,hdrsize,NULL) == SQLITE_OK){
			if(sqlite3_step(m_pStmt) == SQLITE_DONE){
				bRet = TRUE;
			}
		}
		sqlite3_finalize(m_pStmt);
	}
	return bRet;
}

BOOL ADataBase::DeleteMemo(const char* idx)
{
	string sql = "delete from memo where id=";
	sql += idx;

	return (BOOL)sqlite3_exec(m_db,sql.c_str(),NULL,NULL,&m_zErr)==SQLITE_OK;
}

BOOL ADataBase::GetMemoEntries(MemoEntry** ppMemoEntry,size_t* pSize)
{
	int nCount = 0;
	MemoEntry* pme = new MemoEntry;
	MemoEntry* last = pme;

	string sql = "select id,memo_hdr from memo;";
	if(sqlite3_prepare(m_db,sql.c_str(),-1,&m_pStmt,NULL) == SQLITE_OK){
		for(;;){
			switch(sqlite3_step(m_pStmt))
			{
			case SQLITE_ROW:
				{
					MemoEntry* pEntry = new MemoEntry;
					last->next = pEntry;
					last = pEntry;

					memset(pEntry,0,sizeof(MemoEntry));
					int id = sqlite3_column_int(m_pStmt,0);
					unsigned char* hdr = (unsigned char*)sqlite3_column_blob(m_pStmt,1);
					size_t size = sqlite3_column_bytes(m_pStmt,1);

					assert(size>=sizeof(MemoEntry));

					memcpy((unsigned char*)pEntry,hdr,sizeof(MemoEntry));
					_snprintf(pEntry->idx,sizeof(pEntry->idx),"%u",id);

					nCount++;

					break;
				}
			default:
				goto _break;
			}
		}
_break:
		last->next = NULL;
		sqlite3_finalize(m_pStmt);

		//ret
		*pSize = nCount;
		*ppMemoEntry = nCount?pme->next:NULL;
		delete pme;

		return TRUE;

	}else{
		return FALSE;
	}
}
