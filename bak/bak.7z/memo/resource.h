//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by memo.rc
//
#define IDD_MEMO                        101
#define IDD_PASSWORD                    102
#define IDD_NEWPSW                      102
#define IDD_REQPSW                      103
#define IDC_MEMO_EDITCONTENT            1001
#define IDC_MEMO_LISTMEMO               1002
#define IDC_MEMO_NEWMEMO                1003
#define IDC_MEMO_DELMEMO                1004
#define IDC_MEMO_NEWMEMO3               1005
#define IDC_MEMO_SAVEMEMO               1005
#define IDC_EDIT_OLD                    1006
#define IDC_MEMO_SAVEMEMO2              1006
#define IDC_MEMO_CHGPSW                 1006
#define IDC_EDIT_NEW                    1007
#define IDC_EDIT_CONFIRM                1008
#define IDC_BTN_OK                      1009
#define IDC_BTN_CANCEL                  1010
#define IDC_EDIT_REQPSW                 1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
